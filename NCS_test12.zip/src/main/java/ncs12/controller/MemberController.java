package ncs12.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import ncs12.domain.dto.MemberDto;
import ncs12.service.MemberService;

@Controller
@RequestMapping("/mem/*")
public class MemberController {
	
	@Autowired
	private MemberService memberService;//container에서 MemServiceImpl() 객체가 인젝션

	@GetMapping("reg")
	public String regPage() {
		return "member/registration"; // templates 경로
	}
	
	@GetMapping("login")
	public String loginPage() {
		return "member/login"; // templates 경로
	}
	
	@PostMapping("registration")
	public String registration(MemberDto saveDto,Model model) {
		memberService.save(saveDto, model);
		return "/member/login";
	}
	
	public ModelAndView login(MemberDto loginDto) {
		
		return MemberService.loginProcess(loginDto);
	}
	
	@GetMapping
	public String logout() {
		MemberService.logout();
		return "redirect:/";
	}
	
}
