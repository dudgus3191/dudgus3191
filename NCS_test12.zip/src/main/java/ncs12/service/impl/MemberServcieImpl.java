package ncs12.service.impl;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import ncs12.domain.dto.MemberDto;
import ncs12.domain.dto.UserDetails;
import ncs12.mapper.TestMapper;
import ncs12.service.MemberService;

@Service
public class MemberServcieImpl implements MemberService{
	
	@Autowired
	private TestMapper mapper;
	
	@Autowired
	private HttpSession session;
	
	@Override
	public String save(MemberDto dto, Model model) {
		int result=mapper.save(dto);
		if(result==1) {
			model.addAttribute("success", dto.getName()+"님! 회원가입을 축하합니다.");
		}
		return "member/login";
	}

	public ModelAndView loginProcess(MemberDto loginDto) {
		
		ModelAndView mv= new ModelAndView();
		//아이디 확인
		MemberDto result=mapper.findById(loginDto.getId());
		if(result!=null) { //회원인경우
			System.out.println("이메일이 존재합니다");
			//비밀번호확인
			if(loginDto.getPw().equals(result.getPw())) {
				System.out.println("이메일과 비밀번호 일치");
				//로그인처리시작
				System.out.println("session: "+session);
				UserDetails userDetails=
						UserDetails.builder()
						.id(result.getId()).name(result.getName()).build();
				System.out.println("userDetails : "+userDetails);
				session.setAttribute("sUser", userDetails);
				mv.setViewName("redirect:/");//정상처리되있을때 페이지이동
				return mv;
				
			}
			System.out.println("비밀번호 불일치");
		}
		
	////비회원 또는 이멜일 비밀번호 불일치시
		mv.setViewName("member/login");
		String msg="회원이 아니거나 이미 탈퇴한 회원입니다.";
		mv.addObject("error",msg);
		return mv;
	}
	
	

	

}
