package ncs12.service;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import ncs12.domain.dto.MemberDto;

public interface MemberService {

	String save(MemberDto saveDto, Model model);

	 static ModelAndView loginProcess(MemberDto loginDto) {
		// TODO Auto-generated method stub
		return null;
	}

	static void logout() {
		// TODO Auto-generated method stub
		
	}
	

}
