package ncs12.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Builder 
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
public class UserDetails {
	private String id;
	private String name;
}
